#!/bin/bash

docker run -d --name=netflix  -p 8080:80  dhruvdarji123/netflix-react-app:latest 
