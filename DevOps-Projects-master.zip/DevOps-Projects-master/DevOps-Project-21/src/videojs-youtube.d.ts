declare module "videojs-youtube" {}
