# Zomato Clone: Secure Deployment with DevSecOps CI/CD

![zomato-clone](https://miro.medium.com/v2/resize:fit:1400/format:webp/1*X_hm5iF0NRjbOZHB6RQIFA.jpeg)

# 👉 Blog Link: <https://harshhaa.hashnode.dev/zomato-clone-secure-deployment-with-devsecops-cicd>

# 👉 Project Source Code: <https://github.com/NotHarshhaa/Zomato-Clone>

## ✌️ Samples

![Samples](https://miro.medium.com/v2/resize:fit:750/format:webp/1*xVxk3tSbk9yA6hel60t13g.png)
![Samples](https://miro.medium.com/v2/resize:fit:750/format:webp/1*KOwp6K2sOcSmDyk9Axnvhw.png)
![Samples](https://miro.medium.com/v2/resize:fit:750/format:webp/1*t1x_F_qwHI6anvRHS59OxA.png)

# Thank you

Thank you for taking the time to work on this tutorial/labs. Let me know what you thought!

#### Author by [Harshhaa Reddy](https://github.com/NotHarshhaa)

### Ensure to follow me on GitHub. Please star/share this repository
